#pragma once
ref class EdificioCE
{
};

