#pragma once
ref class AreasAL
{
};

