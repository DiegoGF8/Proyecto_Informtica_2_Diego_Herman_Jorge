#pragma once
ref class EdificioBiblioteca
{
};

