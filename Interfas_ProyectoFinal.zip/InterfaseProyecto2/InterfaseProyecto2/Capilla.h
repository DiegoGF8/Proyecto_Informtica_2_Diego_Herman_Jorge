#pragma once
ref class Capilla
{
};

